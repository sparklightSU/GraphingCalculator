package graph;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class Calc extends JPanel{
	
	
	private JFrame frame;
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calc window = new Calc();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}

	/**
	 * Create the application.
	 */
	public Calc() {
		initialize();
		frame.setVisible(true);
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame("Calculator Panel");
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 500, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JCheckBox showFx = new JCheckBox("Show f(x)");
		showFx.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));
		showFx.setForeground(Color.BLUE);
		showFx.setBounds(6, 479, 97, 23);
		frame.getContentPane().add(showFx);
		
		JCheckBox showFpx = new JCheckBox("Show f'(x)");
		showFpx.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));
		showFpx.setForeground(Color.RED);
		showFpx.setBounds(6, 505, 97, 23);
		frame.getContentPane().add(showFpx);
		
		JCheckBox showFppx = new JCheckBox("Show f''(x)");
		showFppx.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));
		showFppx.setForeground(Color.GREEN);
		showFppx.setBounds(6, 531, 97, 23);
		frame.getContentPane().add(showFppx);
		
		JLabel lblNewLabel = new JLabel("hi");
		lblNewLabel.setBounds(6, 89, 46, 14);
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setVisible(false);
		
		JButton btnTest = new JButton("test");
		btnTest.setBounds(10, 114, 89, 23);
		frame.getContentPane().add(btnTest);


		showFx.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				if(showFx.isSelected())
					lblNewLabel.setVisible(true);
				else lblNewLabel.setVisible(false);
			}
		});
	}
	
	public void paintComponent(Graphics g) {
		g.drawLine(200, 200, 400, 200);
	}
}
