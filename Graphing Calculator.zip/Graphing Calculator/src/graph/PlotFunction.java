package graph;

import java.awt.Color;
import java.awt.Font;
import java.util.Scanner;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class PlotFunction {
	public static void main(String[] args){
		JFrame frame = new JFrame("Plot Function");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//just in case some tweaking of graph is needed
		int panelSize = 500;
		int xMaxValue = 5;
		PlotFunctionPanel panel = new PlotFunctionPanel(panelSize,xMaxValue);
		initialize(frame);
		
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.WHITE);
		frame.getContentPane().add(panel);
		frame.pack();
		frame.setVisible(true);
		frame.getContentPane().setLayout(null);
		
		
		
		System.out.println("Integrate? Y/N");
		Scanner sc = new Scanner(System.in);
		String yesOrNo = sc.next();
		if (yesOrNo.toLowerCase().equals("y")) {
			System.out.print("From: ");
			double a = sc.nextDouble();
			System.out.print("To: ");
			double b = sc.nextDouble();
			System.out.println("Integral from " + a + " to " + b + ": " + 
			PlotFunctionPanel.integral(a, b));
			System.out.println("Using the Fundamental Theorem of Calculus: " + 
			PlotFunctionPanel.FTC(a, b));
			System.out.println("Disclaimer: integral function isn't exactly the most accurate. Numbers may be off by a hundreth of a hundreth of a decimal.");
		}
		else System.out.println(
				yesOrNo.toLowerCase().equals("n")?
				"Understandable have a nice day":
				"I'll take that as a no."
				);
		sc.close();
	}
	
	public static void initialize(JFrame frame) {
		JCheckBox showFx = new JCheckBox("Show f(x)");
		showFx.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		showFx.setForeground(Color.BLUE);
		showFx.setBounds(6, 6, 97, 23);
		frame.getContentPane().add(showFx);
		
		JCheckBox showFpx = new JCheckBox("Show f'(x)");
		showFpx.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		showFpx.setForeground(Color.RED);
		showFpx.setBounds(6, 6+26, 97, 23);
		frame.getContentPane().add(showFpx);
		
		JCheckBox showFppx = new JCheckBox("Show f''(x)");
		showFppx.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		showFppx.setForeground(Color.GREEN);
		showFppx.setBounds(6, 6+26+26, 97, 23);
		frame.getContentPane().add(showFppx);

			
			/**************************************************************/
			
			
		showFx.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
					
			}
		});
	}
	public static double function(double x) {
		return Math.sin(x)/x;
		/* FUNCTIONS:
		 * ln(x): Math.log(x)
		 * log(x): Math.log10(x)
		 * log_a(x): logBase(x,a)
		 * ***PS: the log_a(x) function was coded by me using that definiton of a log
		 * sin(x): Math.sin(x)
		 * cos(x): Math.cos(x)
		 * tan(x): Math.tan(x)
		 * x^a: Math.pow(x,a)
		 * e: Math.E
		 * pi: Math.PI
		 * infinity: no
		 * i: don't do this to me please
		 */
	}
	
	
	
	//just in case if this is needed
	public static double logBase(double x, double a) {
		return Math.log(x)/Math.log(a);
	}
}