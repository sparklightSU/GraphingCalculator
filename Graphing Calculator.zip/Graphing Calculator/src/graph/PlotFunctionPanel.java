package graph;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import java.awt.*;

public class PlotFunctionPanel extends JPanel{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int size;
	private static double maxValue;
	
	public PlotFunctionPanel(int size, int maxValue){
		this.size = size;
		this.maxValue = maxValue;
		setPreferredSize(new Dimension(size, size+100));
		}
	
	public void paintComponent(Graphics g){
		g.drawLine(size/2, 0, size/2, size);
		g.drawLine(0, size/2, size, size/2);
		double[] tick = getTicks();
		int w = size/10, h = size/2, vA = 8;
		g.setFont(new Font("Comic Sans MS", Font.PLAIN, size/30));
		for(int i = 0; i < 9; i++){
			g.drawLine(w, h+5, w, h-5);
			if(i != 4 && vA != 4){
				if(i > 4)
					g.drawString(tick[i]+"", w-size/40, h+size/21);
				else
					g.drawString(tick[i]+"", w-size/30, h+size/21);
				if(vA > 4)
					g.drawString(tick[vA]+"", h-size/13, w+size/60);
				else
					g.drawString(tick[vA]+"", h-size/12, w+size/60);
			}
			g.drawLine(h+5, w, h-5, w);
			w+=size/10;
			vA--;
		}
		g.setColor(Color.BLUE);
		
		double x = (-maxValue), max = maxValue, ratio = size/(max*2); 
		int radiusFP = 10;
		int radiusFPP = 15;
		
		
		//f(x)
        for(;x<=max;x+=0.0001){
            g.drawLine((int)(size/2+(ratio*x)), 
            		(int)(size/2-(ratio*f(x))),
                    (int)(size/2+(ratio*x)), 
                    (int)(size/2-(ratio*f(x)))
                    );
        }
        
        //f'(x)
        x = (-maxValue);
        for(;x<=max;x+=0.0001){
            g.setColor(Color.RED);
            g.drawLine((int)(size/2+(ratio*x)),
            		(int)(size/2-(ratio*fp(x))),
                    (int)(size/2+(ratio*x)),
                    (int)(size/2-(ratio*fp(x))));
            
            //Look for min/max
            if(fp(x) <= 0.0001 && fp(x) >= -0.0001) {
            	int xC, fxC;
            	xC = ((int)(size/2+(ratio*x))-(radiusFP/2));
            	fxC = ((int)(size/2-(ratio*f(x)))-(radiusFP/2));
            	g.drawArc(xC, fxC, radiusFP, radiusFP, 0, 360);
            }
            
        }
        
        //f''(x)
        x = (-maxValue);
        for(;x<=max;x+=0.0001){
            g.setColor(Color.GREEN);
            g.drawLine((int)(size/2+(ratio*x)),
            		(int)(size/2-(ratio*fpp(x))),
                    (int)(size/2+(ratio*x)),
                    (int)(size/2-(ratio*fpp(x))));
            
            //Look for points of inflection
            if(fpp(x) <= 0.0001 && fpp(x) >= -0.0001) {
            	int xC, fxC;
            	xC = ((int)(size/2+(ratio*x))-(radiusFPP/2));
            	fxC = ((int)(size/2-(ratio*f(x)))-(radiusFPP/2));
            	g.drawArc(xC, fxC, radiusFPP, radiusFPP, 0, 360);
      		  
            }
            
        }
	  
	}
	
	//functions (self-explanatory)
	public static double f(double x) {
		return PlotFunction.function(x);
	}
	public static double fp(double x) {
		return (f(x+0.0001)-f(x))/0.0001;
	}
	public static double fpp(double x) {
		return (fp(x+0.0001)-fp(x))/0.0001;
	}
	
	//integration (via Riemann's sum)
	public static double integral(double a, double b) {
		double sum = 0;
		double increment = 0.00000001;
		for(;a<b;a+=increment) {
			sum += increment * f(a);
		}
		return sum;
	}
	
	//integration (via FTC), TODO because doesn't work
	public static double FTC(double a, double b) {
		return integral(0,b) - integral(0,a);
	}
	
	private static double[] getTicks(){
		double increment = maxValue / 5, currentTick = -1*(maxValue);
		double[] tick = new double[9];
		for(int i = 0; i < 9; i++){
			currentTick+=increment;
			tick[i] = Math.round(currentTick*100.0)/100.0;
		}
		return tick;
	}
}
